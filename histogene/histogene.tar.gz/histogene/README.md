# histogene/

HisToGene port for the benchmark. Same shape as `bleep/`: config, her2st loader,
patch cache, dataset, preflight, train, score, driver scripts.

The model itself is imported unmodified from a clone of
[maxpmx/HisToGene](https://github.com/maxpmx/HisToGene) (`vis_model.HisToGene`).
Nothing else from that repo is used — its `dataset.py` hard-codes a 785-gene
list, raises `KeyError` on genes missing from a section's count matrix, and holds
~34 GB of decoded images in RAM; its `utils.py`/`predict.py` pull in `scprep`,
which pins `pandas<2.1` and no longer builds.

**Step-by-step: [RUNBOOK.md](RUNBOOK.md) (中文).**

## Files

| file | what |
|---|---|
| `config.py` | paths (repo-relative by default) + hyperparameters, all env-overridable |
| `her2st.py` | sections, counts, spot files, panel, expression target, fold definitions |
| `cache.py` | one-off 112×112 uint8 patch cache + expression cache |
| `dataset.py` | section-level Dataset reproducing the upstream tensor layout |
| `build_cache.py` | `python -m histogene.build_cache` |
| `preflight.py` | `python -m histogene.preflight` — checks + 2-epoch smoke test |
| `train.py` | `python -m histogene.train --cv patient --fold 0 --tag ...` |
| `score.py` | `python -m histogene.score --tag ...` → `results/<tag>/` |
| `run_lopo.sh` / `run_loso.sh` | drivers |
| `env.sh` | pod environment variables |

All commands run from the **st_benching repo root**.

## Protocol

| | |
|---|---|
| panel | `panels/panel_833.txt`, fixed order, missing genes zero-filled |
| target | `log10(CP10K + 1)`, library size over panel columns only |
| model | `n_layers=8, dim=1024, heads=16, dropout=0.1, patch=112, n_pos=64` |
| optimiser | Adam, `lr=1e-5`, `batch_size=1` (one section per step) |
| budget | 100 epochs, scored at the **last** epoch, no held-out selection |
| CV | `patient` (8 folds, main result) or `section` (upstream split, 7 folds) |
| metric | per-gene PCC computed **within** each fold, averaged across folds |

## Paths

Repo-relative and needing no configuration: `panels/panel_833.txt`,
`results/gene_sets/`, `results/<tag>/`.
On the volume and out of git: `/workspace/cache/htg_patch112` (patch cache,
~600 MB), `/workspace/runs/<tag>` (predictions, loss curves, run.json).

Note the patch cache is **separate** from the 224×224 `her2st_cache` built for
BLEEP — HisToGene crops 112×112 (`r = 224 // 4`), so the two cannot be shared.

## Quick start

```bash
cd /workspace/st_benching && source histogene/env.sh
pip install -r histogene/requirements.txt
python -m histogene.build_cache
python -m histogene.preflight
bash histogene/run_lopo.sh histogene_lopo_833
python -m histogene.score --tag histogene_lopo_833
```
