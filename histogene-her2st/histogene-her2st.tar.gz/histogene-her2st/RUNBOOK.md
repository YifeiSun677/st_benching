# HisToGene × her2st × 833-gene panel — 训练 Runbook

从零到出结果的完整流程。目标：在 RunPod 上用**原版 maxpmx/HisToGene** 的模型代码，
在自己的 her2st 数据和自己的 833 panel 上跑完 LOPO（8 folds）和可选的 LOSO（7 folds），
并按 per-fold PCC 打分。

---

## 0. 总体设计（先看这段，能省掉后面一半的调试）

### 0.1 我们用原 repo 的什么，不用什么

| 原 repo 文件 | 用不用 | 原因 |
|---|---|---|
| `vis_model.py` → `HisToGene` | **用**（原样 import） | 这是模型本体，不改，保证和论文一致 |
| `transformer.py` → `ViT` | **用**（被 `vis_model` 间接 import） | 同上 |
| `dataset.py` → `ViT_HER2ST` | **不用**，自己重写 | 见 0.2 |
| `utils.py` / `predict.py` | **不用** | 它们 `import scprep`，而 scprep 1.2.3 要求 `pandas<2.1`，且在新 setuptools 下连装都装不上（`pkg_resources` 缺失）。我们只需要它两行算术，用 numpy 重写了 |
| `tutorial.ipynb` | 只作参考 | 超参来源：`n_layers=8, n_genes=785, lr=1e-5, max_epochs=100, batch_size=1` |

一句话：**只 `from vis_model import HisToGene`，其余全部自己实现。**

### 0.2 为什么必须重写 dataset

原版 `ViT_HER2ST` 有四个问题，全都会挡住这次运行：

1. **内存**：`self.img_dict = {i: torch.Tensor(np.array(self.get_img(i))) for i in names}`
   把每张训练切片整张读成 float32。her2st 单图约 9300×9900，一张 ≈ 1.1 GB，
   LOPO 训练集约 31 张 → **约 34 GB 常驻内存**，还要每个 fold 重新解一次 JPEG。
   → 解法：一次性建 112×112 uint8 patch cache（约 560 MB），memmap 读。
2. **基因列表写死**：函数签名里有 `gene_list=None`，但函数体第一行就
   `gene_list = list(np.load('data/her_hvg_cut_1000.npy', ...))` 把它覆盖了。
   传参无效。顺带一提，这个文件名叫 `cut_1000`，里面其实是 **785** 个基因。
3. **缺失基因会崩**：`m[self.gene_set]` 直接对 DataFrame 取列。her2st 的 `ST-cnts`
   只保存该切片检测到的基因，稀疏基因在个别切片里根本没有列 → `KeyError`。
   → 解法：**zero-fill**（与 benchmark 的全局约定一致，panel 长度恒定 833）。
4. **归一化范围**：`m[gene_set]` 先取子集再归一化，所以 library size 是**只在 panel
   内求和**的。我们照抄这个行为，不要"顺手改成全基因组归一化"。

### 0.3 保持与原版逐位一致的三个细节

这三点看着像 bug，但**不要改**，改了就和原论文/其他人的复现不可比：

- **patch 不除以 255**。`patches[i] = patch.flatten()` 直接把 0–255 的浮点喂进
  `Linear(37632 → 1024)`。
- **patch 是转置的**。原码先 `im.permute(1,0,2)` 把整图变成 (x, y, c) 再裁，
  所以 flatten 顺序是 HWC 的转置。我们的 dataset 用 `transpose(0,2,1,3)` 复现。
- **target = log10(CP10K + 1)**，不是自然对数 `log1p`。
  `scprep.normalize.library_size_normalize` 默认 `rescale=10000`，
  `scprep.transform.log` 默认 `base=10, pseudocount=1`。
  这点在跨模型比较时很关键：ST-Net 存的是 log-softmax，尺度完全不同，
  **MSE / R² / baseline gain 不可直接对比，PCC 不受影响**。

### 0.4 协议（写论文时要能一句话说清）

- panel：833 基因（785-HVG ∪ PAM50），缺失基因 zero-fill，列顺序固定。
- 超参：`n_layers=8, dim=1024, heads=16, dropout=0.1, patch_size=112, n_pos=64, lr=1e-5, Adam`。
- 预算：**固定 100 epochs，在最后一个 epoch 打分**，不做任何基于 held-out 的 epoch 选择。
- CV：
  - `--cv patient`：leave-one-patient-out，8 折（A–H），36 张切片全用上。**主结果。**
  - `--cv section`：复现原 repo 的 `samples = names[1:33]` 划分。
    注意这个划分**静默排除了 A1 和整个 H 病人**。默认只跑每个病人一张：
    fold 0/5/11/17/23/26/29 = A2 B1 C1 D1 E1 F1 G1。
- 打分：**per-fold 内算 per-gene PCC，再跨 fold 平均**。
  不要把所有 fold 的预测拼成一个大矩阵再算 —— 在 her2st 上 section 级 batch effect
  会污染 pooled PCC，甚至翻转符号。

---

## 1. Mac 端：建 repo 并 push

```bash
cd ~/Documents/science
# 把本 repo 解压/放到这里，目录名 histogene-her2st
cd histogene-her2st

# 833 panel 从 st_benching 复制过来（唯一需要你手动补的文件）
cp ~/Documents/science/st_benching/panels/panel_833.txt panels/panel_833.txt
wc -l panels/panel_833.txt        # 应为 833

git init
git add .
git commit -m "HisToGene her2st 833-panel training harness"
git branch -M main
git remote add origin https://github.com/YifeiSun677/histogene-her2st.git
git push -u origin main
```

GitHub 上先建一个空的 public repo `histogene-her2st`（不要勾 README/.gitignore，
否则 push 会冲突）。之后 pod 上全部用 `git pull` 同步，不用 scp。

---

## 2. RunPod：部署 pod

**顺序很重要**：

1. 先进 **Storage** 页面，选中已有的 network volume（就是挂 `/workspace` 那个）。
   > 千万不要在部署页面用 "Automatically create" 建 volume —— 那种 volume 会随
   > pod 一起销毁，之前 her2st 预处理数据就是这么没的。
2. 从那个 volume 点 **Deploy**，然后再选 GPU。GPU 列表会自动过滤到该 volume 所在的
   datacenter；反过来先选 GPU 就可能选到挂不上 volume 的机器。
3. GPU：**RTX 4090**（24 GB 足够，峰值只用 3–5 GB）。
   vCPU 越多越好（≥8），因为 dataloader 侧是 CPU 拷贝。
4. 模板：官方 **PyTorch** 镜像（自带 torch + CUDA，不要自己装 torch）。
5. Container disk 给 20 GB 即可，所有产物都写 `/workspace`。

SSH 进去：

```bash
ssh root@<POD_IP> -p <PORT> -i ~/.ssh/id_ed25519
```

---

## 3. Pod 首次初始化

```bash
cd /workspace

# 3.1 原版 HisToGene（只要模型代码）
git clone https://github.com/maxpmx/HisToGene.git

# 3.2 本 harness
git clone https://github.com/YifeiSun677/histogene-her2st.git
cd histogene-her2st

# 3.3 环境变量（每次新开 shell 都要 source）
source scripts/00_env.sh

# 3.4 依赖（torch 已经有了，只补这几个）
pip install -r requirements.txt
```

`requirements.txt` 只有 `pytorch-lightning / torchmetrics / einops / numpy / pandas /
Pillow / tqdm / scipy`。**不要 `pip install torch`**，会把镜像自带的 CUDA 版本换掉。

> PL 版本注意：`tutorial.ipynb` 写的是 `pl.Trainer(gpus=0, max_epochs=100)`，
> `gpus=` 是 Lightning 1.x 的参数，2.x 已删除。本 harness 用的是
> `accelerator="gpu", devices=1`，所以装 PL 2.x 就行，不需要降级。
>
> 另一个坑：`vis_model.py` 里 `HisToGene.__init__` 的 `self.save_hyperparameters()`
> 被注释掉了，所以 `.ckpt` 里没有超参。如果你以后用 `load_from_checkpoint`，
> **必须显式重传** `n_layers=8, n_genes=833, learning_rate=1e-5`，否则会用默认值
> `n_layers=4, n_genes=1000` 加载失败。

---

## 4. 数据就位检查

her2st 目录结构必须是这样（`HTG_HER2ST` 指向的是**包含**这三个子目录的那层）：

```
/workspace/her2st/data/
├── ST-cnts/        A1.tsv … H3.tsv        （36 个）
├── ST-imgs/A/A1/   HE_BT….jpg
└── ST-spotfiles/   A1_selection.tsv …
```

```bash
ls /workspace/her2st/data/ST-cnts | wc -l          # 36
ls /workspace/her2st/data/ST-spotfiles | wc -l     # 36
du -sh /workspace/her2st/data                      # ~714 MB
```

> 如果你的 `ST-cnts` 是 `.tsv.gz`，本 harness 能直接读（pandas 自动解压）；
> 但**原版 `dataset.py` 只认 `.tsv`**，所以如果你以后想直接跑原 repo，
> 需要先 `gunzip`。

---

## 5. 建 patch cache（一次性，约 10–20 分钟）

```bash
cd /workspace/histogene-her2st
source scripts/00_env.sh
python scripts/01_build_cache.py
```

产出：

```
/workspace/cache/htg_patch112/
├── patches/<section>.npy     uint8 (n_spots, 112, 112, 3)   合计 ~560 MB
├── patches/<section>.npz     spot_id / array_x,y / pixel_x,y
├── expr/<panel_hash>/*.npy   float32 (n_spots, 833)          ~45 MB
├── patch_cache_report.json   每张切片的 spot 数、边缘补零数、array 坐标最大值
└── panel_coverage.csv        每张切片实际含有多少个 panel 基因
```

要看的两件事：

- `patch_cache_report.json` 里 `n_padded` 应该全是 0。若不是 0，说明有 spot 离图边
  不足 56 px，被补零了 —— 记下来，写 methods 时要提。
- `panel_coverage.csv` 的 `missing` 列就是被 zero-fill 的基因数，每张切片会不一样，
  这是 her2st 的正常现象（`ST-cnts` 只存该切片检测到的基因）。

这一步做完，后面每个 fold 的启动时间从"十几分钟解 JPEG + 34 GB 内存"变成"几秒"。

---

## 6. Pre-flight + 冒烟测试（约 2–3 分钟）

```bash
python scripts/02_preflight.py
```

它会依次检查：路径 → import → CUDA → 36 切片 / 833 基因 → cache 完整性 →
target 算术（若装了 scprep 会和 scprep 逐元素比对）→ fold 划分 →
一次前向（应打印 `parameters: 106.7 M`，输出 `(1, n_spots, 833)`）→
3 张切片跑 2 个 epoch，并**外推出单折 100 epoch 的预计耗时**。

必须全是 `[OK ]` 才往下走。其中两条是故意的"反向断言"：

- `patch scale is 0-255` —— max 应 > 1.5，证明没有被除以 255。
- `array coords < n_pos` —— her2st array 坐标最大约 33/35，`n_pos=64` 够用。

---

## 7. 计时试跑（约 1–3 分钟）

正式开跑前先用 5 个 epoch 量一次真实速度：

```bash
python scripts/03_train_fold.py --cv patient --fold 0 --tag timing --epochs 5
cat /workspace/runs/timing/fold00_A/run.json | grep -E "sec_per_epoch|peak_gpu_gb"
```

用 `sec_per_epoch × 100 × 8 / 3600` 估算 LOPO 总时长。
如果 `sec_per_epoch` 明显偏高（比如 > 20 s），先调 `--workers`（试 4 / 8 / 16）。

跑完把 timing 目录删掉，别混进正式结果：

```bash
rm -rf /workspace/runs/timing results/timing
```

---

## 8. 正式跑 LOPO（8 折 × 100 epochs）

**一定要用 tmux**，SSH 断线会杀掉进程：

```bash
tmux new -s htg
cd /workspace/histogene-her2st && source scripts/00_env.sh
bash scripts/run_lopo.sh lopo_833
# Ctrl-b d 脱离；tmux attach -t htg 回来
```

监控：

```bash
tail -f /workspace/runs/lopo_833/logs/fold0.log
watch -n 5 nvidia-smi
```

每折产出：

```
/workspace/runs/lopo_833/fold00_A/
├── preds/A1.npz  A2.npz  …     pred / truth / centers / spot_id / genes
├── loss_curve.csv               epoch, train_loss, seconds   ← 上次那版没有
└── run.json                     完整配置 + 计时 + peak GPU
```

> `loss_curve.csv` 是这次特意补的。上一版 run.json 只有配置和总时长，没有 epoch 曲线，
> 结果没法回答"100 epoch 到底收敛没有"。现在可以直接看。

---

## 9. （可选）LOSO 协议对照

```bash
bash scripts/run_loso.sh loso_833          # 默认 7 折：A2 B1 C1 D1 E1 F1 G1
# 或指定：bash scripts/run_loso.sh loso_833 0 5 11 17 23 26 29
```

---

## 10. 打分

```bash
python scripts/04_score.py --tag lopo_833
# 带上 benchmark 统一的 gene set 分层：
python scripts/04_score.py --tag lopo_833 --gene_sets ~/science/results/gene_sets
```

输出到 `results/lopo_833/`：

- `per_fold.csv` —— 每折的 gene PCC mean/median、正相关基因比例、spot PCC、
  SSE ratio（相对 held-out 自身 per-gene mean 的 baseline）。
- `per_gene.csv` —— 每个基因跨折平均 PCC，外加每折单独的列。
- `summary.json` —— headline 数字 + marker 基因（ERBB2 / GRB7 / ESR1 / PGR /
  FASN / GNAS / MKI67）+ gene set 分层。

`--unit fold`（默认）= 每折内把该病人的所有切片拼起来算 PCC；
`--unit section` = 每张切片单独算再平均。两个都跑一下当 sensitivity check。

---

## 11. 回传 Mac

```bash
# 在 Mac 上执行
rsync -avz -e "ssh -p <PORT> -i ~/.ssh/id_ed25519" \
  root@<POD_IP>:/workspace/histogene-her2st/results/ \
  ~/Documents/science/st_benching/results/

rsync -avz -e "ssh -p <PORT> -i ~/.ssh/id_ed25519" \
  root@<POD_IP>:/workspace/runs/lopo_833/ \
  ~/Documents/science/histogene_results/lopo_833/
```

小的 CSV / summary.json 进 `st_benching` git；`.npz` 和 `.ckpt` 不进 git。

---

## 12. 时间与资源预算

RTX 4090 / ≥8 vCPU / 32 GB RAM，仅供规划，真实数字以第 7 步为准。

| 步骤 | 预计耗时 | 备注 |
|---|---|---|
| 1 Mac 建 repo + push | 10 min | 一次性 |
| 2 部署 pod | 3–5 min | 先选 volume 再选 GPU |
| 3 clone + 装依赖 | 3–5 min | |
| 4 数据检查 | 1 min | |
| 5 建 patch cache | **10–20 min** | 一次性；volume 在就不用重做 |
| 6 pre-flight + 冒烟 | 2–3 min | |
| 7 计时试跑（5 epoch） | 1–3 min | |
| 8 **LOPO 8 折 × 100 epoch** | **1.5–3 h** | 每折约 10–20 min |
| 9 LOSO 7 折（可选） | 1.5–2.5 h | |
| 10 打分 | < 2 min | |
| 11 回传 | 5 min | |
| **只跑 LOPO 的总墙钟** | **约 2.5–4 h** | |
| **LOPO + LOSO** | **约 4.5–7 h** | |

资源占用：

| 项 | 数值 |
|---|---|
| 模型参数 | 106.7 M（patch_embedding 38.5 M + ViT 67.2 M + head 0.9 M） |
| GPU 显存峰值 | 约 3–5 GB（24 GB 卡绰绰有余） |
| 主机内存 | 约 2–4 GB（原版不加 cache 是 ~34 GB） |
| patch cache 磁盘 | 约 560 MB |
| 每折预测文件 | 约 2–10 MB；全部 folds 合计 < 100 MB |

省钱提示：cache 建好后 GPU 才真正开始用得上。如果 pod 按小时计费，
第 5 步可以在便宜的 GPU 上做（它是纯 CPU 活），再换 4090 跑训练 —— 前提是
换 pod 时**选同一个 network volume**。

---

## 13. 常见坑速查表

| 症状 | 原因 | 处理 |
|---|---|---|
| pod 重启后数据没了 | volume 是部署时 "Automatically create" 的 | 只用 Storage 页面手动建的 volume |
| `KeyError: 'XXX'` 取基因列 | 该切片 `ST-cnts` 里没有这个基因 | 已由 zero-fill 处理；若报错说明绕过了本 harness |
| OOM / 进程被 kill | 用了原版 `ViT_HER2ST`（34 GB） | 用 `htg.dataset.HER2STSections` |
| `TypeError: __init__() got an unexpected keyword argument 'gpus'` | 抄了 tutorial 的 PL 1.x 写法 | `accelerator="gpu", devices=1` |
| `pip install scprep` 构建失败 | 新 setuptools 移除了 `pkg_resources` | 不装；本 harness 不需要它 |
| `load_from_checkpoint` 尺寸不匹配 | repo 注释掉了 `save_hyperparameters()` | 显式传 `n_layers=8, n_genes=833` |
| `array coord >= n_pos` | panel/坐标异常 | 检查 spotfile 的 `x`/`y` 列 |
| PCC 是负的、比 mean baseline 还差 | 把所有 fold pool 起来算了 | 用 `04_score.py` 的 per-fold 口径 |
| MSE 和 ST-Net 对不上 | target 尺度不同（log10(CP10K+1) vs log-softmax） | 只比 PCC；MSE/R² 要先统一尺度 |
| SSH 断了训练也断了 | 没用 tmux | `tmux new -s htg` |
| 每折启动要十几分钟 | patch cache 没建 / 路径不对 | 检查 `HTG_CACHE` 与第 5 步产物 |

---

## 14. 一页纸命令清单

```bash
# pod 上，每次新 shell
cd /workspace/histogene-her2st && source scripts/00_env.sh && git pull

# 一次性
python scripts/01_build_cache.py

# 每次开跑前
python scripts/02_preflight.py
python scripts/03_train_fold.py --cv patient --fold 0 --tag timing --epochs 5

# 正式
tmux new -s htg
bash scripts/run_lopo.sh lopo_833
bash scripts/run_loso.sh loso_833          # 可选

# 打分
python scripts/04_score.py --tag lopo_833 --gene_sets ~/science/results/gene_sets
python scripts/04_score.py --tag lopo_833 --unit section
```
