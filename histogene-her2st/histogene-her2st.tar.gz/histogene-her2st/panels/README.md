Put `panel_833.txt` here: one HGNC symbol per line, 833 lines, no header.

    cp ~/Documents/science/st_benching/panels/panel_833.txt panels/panel_833.txt
    wc -l panels/panel_833.txt   # 833

Gene order in this file defines the column order of every prediction and
ground-truth matrix the harness writes, so it must not change between runs.
