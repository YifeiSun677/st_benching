# histogene-her2st

Training harness for [maxpmx/HisToGene](https://github.com/maxpmx/HisToGene) on the
her2st dataset with a fixed 833-gene panel (785-HVG ∪ PAM50).

The model itself is imported unmodified from the upstream repo
(`vis_model.HisToGene`). Everything else — data loading, patch caching, the gene
panel, fold definitions, prediction I/O and scoring — lives here, because the
upstream `dataset.py` hard-codes a 785-gene list, crashes on genes missing from a
section's count matrix, and holds ~34 GB of decoded images in RAM.

**Full step-by-step instructions: [RUNBOOK.md](RUNBOOK.md) (中文).**

## Layout

```
htg/
  config.py     paths + hyperparameters, all env-overridable
  her2st.py     sections, counts, spot files, panel, target, folds
  cache.py      one-off 112x112 uint8 patch cache + expression cache
  dataset.py    section-level Dataset matching upstream tensor layout
scripts/
  00_env.sh           environment variables for the pod
  01_build_cache.py   build caches (run once)
  02_preflight.py     checks + 2-epoch smoke test
  03_train_fold.py    train one fold, write predictions
  04_score.py         per-fold per-gene PCC, averaged across folds
  run_lopo.sh         8 folds, leave-one-patient-out
  run_loso.sh         repo-native leave-one-section-out
panels/
  panel_833.txt       one HGNC symbol per line  (copy from st_benching)
```

## Protocol

| | |
|---|---|
| panel | 833 genes, fixed order, missing genes zero-filled |
| target | `log10(CP10K + 1)`, library size over panel columns only |
| model | `n_layers=8, dim=1024, heads=16, dropout=0.1, patch=112, n_pos=64` |
| optimiser | Adam, `lr=1e-5`, `batch_size=1` (one section per step) |
| budget | 100 epochs, scored at the **last** epoch, no held-out selection |
| CV | `patient` (8 folds, main) or `section` (upstream split, 7 folds reported) |
| metric | per-gene PCC computed **within** each fold, averaged across folds |

## Quick start

```bash
source scripts/00_env.sh
pip install -r requirements.txt
python scripts/01_build_cache.py
python scripts/02_preflight.py
bash scripts/run_lopo.sh lopo_833
python scripts/04_score.py --tag lopo_833
```
